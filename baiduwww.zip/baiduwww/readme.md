本说明是针对那些启动页是远程服务器上的文件的说明
也就是一些打包平台输入网址进行打包的，或者本地打包，但是index文件是指向远程服务器上内容的

1.本目录文件除本说明文件外都复制到网站服务器的根目录下，也就是www目录下
2.根据https://github.com/baidumobad/baidu-ssp-phonegap-plugin把插件打包到app里面
3.把下面代码复制到网站的需要展示广告的页面（根据自己的需求修改代码），如果所有页面都要展示，最好是放到footer或者header之类的里面，和统计类型的代码一个位置

<script type="text/javascript" src="cordova.js"></script>
<script type="text/javascript">
     function onInterstitialReceive(message) {
	     baiduAd.showInterstitial();//加载完成后展示广告
     }
    function onDeviceReady() {
        baiduAd.initBanner("应用id", "横幅广告位");
        baiduAd.showBanner(baiduAd.AD_POSITION.BOTTOM_CENTER);

	document.addEventListener('onInterstitialReceive', onInterstitialReceive, false);//监听广告加载成功事件
  	baiduAd.initInterstitial("应用id", "插屏广告位");//创建广告
 	baiduAd.cacheInterstitial();//创建全屏完成后加载广告
    }

document.addEventListener('deviceready',onDeviceReady, false);
</script>

附：百度封号严重，不要搞作弊的行为
