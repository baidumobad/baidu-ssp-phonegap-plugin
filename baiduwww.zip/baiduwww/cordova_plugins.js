cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.baidu.cordova.plugin.BaiduAdPlugin/www/BaiduAdPlugin.js",
        "id": "com.baidu.cordova.plugin.BaiduAdPlugin.BaiduAd",
        "clobbers": [
            "window.baiduAd"
        ]
    },
    {
        "file": "plugins/cordova-plugin-whitelist/whitelist.js",
        "id": "cordova-plugin-whitelist.whitelist",
        "runs": true
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.baidu.cordova.plugin.BaiduAdPlugin": "1.0.0",
    "cordova-plugin-whitelist": "1.2.1"
};
// BOTTOM OF METADATA
});